# Module Home cinéma (remplace K-Touch)

Pilote directement, sans K-Touch :

| Appareil | IP | Protocole | Fichier |
|---|---|---|---|
| Kramer SL-12 (projecteur, écran, lift) | 192.168.1.200 | UDP 50000, `#01@BTN n,11,R` | `devices.ts → sl12` |
| Yamaha RX-A1040 | 192.168.1.210 | TCP 50000, YNCA | `devices.ts → yamaha` |
| Blu-ray Sony | 192.168.1.211 | HTTP 50001, IRCC + Wake-on-LAN | `devices.ts → sony` |
| Décodeur Orange | 192.168.1.10 | HTTP 8080 | `devices.ts → orange` |

Toutes les adresses et tous les codes sont dans `config.ts`.

## Installation dans ton app

```bash
npm install react-native-udp react-native-tcp-socket buffer
cd ios && pod install    # si projet bare
```
Avec Expo : ces modules sont natifs → **dev build** obligatoire (`npx expo prebuild` / EAS), pas Expo Go.

Copie `src/homecinema/` dans ton projet et ajoute l'écran :
```tsx
import HomeCinemaScreen from './src/homecinema/HomeCinemaScreen';
<Stack.Screen name="HomeCinema" component={HomeCinemaScreen} options={{ title: 'Home cinéma' }} />
```

## Réglages natifs indispensables

**iOS – `Info.plist`**
```xml
<key>NSLocalNetworkUsageDescription</key>
<string>Pour piloter l'ampli, le projecteur et le lecteur Blu-ray de la maison.</string>
<key>NSAppTransportSecurity</key>
<dict><key>NSAllowsLocalNetworking</key><true/></dict>
```
⚠️ Le Wake-on-LAN part en **broadcast** : depuis iOS 14, Apple exige l'entitlement
`com.apple.developer.networking.multicast` (à demander à Apple). Sans lui, sur iPhone,
essaie `broadcast: '192.168.1.211'` dans `config.ts` (WOL en unicast — marche souvent).
Sur Android, aucun souci.

**Android – `AndroidManifest.xml`** (HTTP non chiffré vers le Sony et le décodeur)
```xml
<application android:usesCleartextTraffic="true" ...>
```

## Ce qui a été corrigé par rapport à K-Touch

- **L'ampli est allumé** (`@MAIN:PWR=On`) avant le changement d'entrée — K-Touch ne le faisait jamais, d'où l'absence de son/image.
- Une requête « réveil » est envoyée à l'ampli à chaque connexion (il ignore la 1re commande).
- Les boutons SL-12 sont espacés de 500 ms (K-Touch en envoyait deux en 2 ms).
- Le **Power du Sony est une bascule** : il n'est envoyé que si le lecteur dormait (sinon passer de CD à Film l'éteignait).
- L'ampli n'accepte qu'une connexion YNCA : l'app la ferme en arrière-plan.

## À vérifier / limites connues

- **Apple TV** : pas réveillée par l'app (le protocole Companion n'a pas de lib JS fiable).
  Pistes : activer le HDMI-CEC (Apple TV : Réglages > Télécommandes et appareils >
  *Contrôler téléviseurs et récepteurs* ; Yamaha : *HDMI Control* ON) et tester si
  l'allumage de l'ampli sur AV2 la réveille ; sinon un petit pont pyatv sur un Raspberry Pi.
- La MAC `D8:D4:3C:F1:4D:D3` a été lue sur l'écran Wake-on-LAN de la gateway en **POST**,
  donc a priori le Sony (le décodeur utilise des GET). À confirmer.
- Rôle des boutons SL-12 supposé : 9 = projecteur ON, 5/7 = descente, 6/8 = remontée,
  2 = projecteur OFF, 4 = format 1.33, 1 = inconnu.
- Le décodeur Orange n'est pas allumé par le scénario TV (K-Touch ne le faisait pas non plus).
